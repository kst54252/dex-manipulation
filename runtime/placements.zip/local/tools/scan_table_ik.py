#!/usr/bin/env python3
"""Offline tabletop IK / full collision-geometry audit. All outputs stay local."""
import argparse
from concurrent.futures import ProcessPoolExecutor, as_completed
from dataclasses import asdict
import hashlib
import json
import multiprocessing as mp
from pathlib import Path
import sys
import time

import numpy as np
from scipy.spatial.transform import Rotation, Slerp

ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT / 'src'))
from dex_manipulation.fk import ArmModel, HandModel
from dex_manipulation.ik import ArmIK, IKOptions, interpolate_ik_source, model_fingerprint
from dex_manipulation.scene import Workcell
from dex_manipulation.transforms import inverse, apply
from dex_manipulation.usd import convex_surface

GROUPS = ('hand_arm', 'arm_self', 'hand_self', 'environment', 'hand_can', 'arm_can')


def digest(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def extract_collision_audit(config):
    """Extract every enabled authored hull in its actual rigid-body local frame."""
    from pxr import Usd, UsdGeom, UsdPhysics
    stage = Usd.Stage.Open(str(ROOT / config['usd']))
    cache = UsdGeom.XformCache()
    scale = UsdGeom.GetStageMetersPerUnit(stage)
    prims = list(Usd.PrimRange.Stage(stage, Usd.TraverseInstanceProxies()))
    arm = ArmModel.load(ROOT / config['arm_model'])
    hand = HandModel.load(ROOT / config['hand_model'])
    known = set(arm.description['link_paths']) | set(hand.description['link_paths'])
    arm_links = set(arm.description['link_paths']) - {hand.root}
    def world(prim):
        t = np.asarray(cache.GetLocalToWorldTransform(prim)).T.copy()
        t[:3, 3] *= scale
        return t
    def body(prim):
        while prim and not prim.HasAPI(UsdPhysics.RigidBodyAPI):
            prim = prim.GetParent()
        return prim
    colliders, excluded, articulations, filters = [], [], [], []
    for prim in prims:
        if prim.HasAPI(UsdPhysics.ArticulationRootAPI) or prim.GetAttribute('physxArticulation:enabledSelfCollisions').IsValid():
            articulations.append(dict(path=str(prim.GetPath()), active_root=prim.HasAPI(UsdPhysics.ArticulationRootAPI),
                schemas=list(prim.GetAppliedSchemas()), newton_self_collision=prim.GetAttribute('newton:selfCollisionEnabled').Get(),
                physx_self_collision=prim.GetAttribute('physxArticulation:enabledSelfCollisions').Get()))
        for rel in prim.GetRelationships():
            if 'filtered' in rel.GetName().lower() and rel.GetTargets():
                filters.append(dict(path=str(prim.GetPath()), relationship=rel.GetName(), targets=[str(x) for x in rel.GetTargets()]))
        if prim.IsA(UsdPhysics.Joint):
            joint = UsdPhysics.Joint(prim)
            if joint.GetJointEnabledAttr().Get() is False or joint.GetCollisionEnabledAttr().Get() is True:
                continue
            a, b = joint.GetBody0Rel().GetTargets(), joint.GetBody1Rel().GetTargets()
            if len(a) == len(b) == 1:
                pa, pb = body(stage.GetPrimAtPath(a[0])), body(stage.GetPrimAtPath(b[0]))
                if pa and pb:
                    excluded.append(dict(joint=prim.GetName(), links=sorted([pa.GetName(), pb.GetName()])))
        if not prim.HasAPI(UsdPhysics.CollisionAPI) or UsdPhysics.CollisionAPI(prim).GetCollisionEnabledAttr().Get() is False:
            continue
        parent = body(prim)
        if not parent or parent.GetName() not in known:
            raise ValueError(f'Unknown collider body: {prim.GetPath()}')
        approximation = prim.GetAttribute('physics:approximation').Get()
        if not prim.IsA(UsdGeom.Mesh) or approximation != 'convexHull':
            raise ValueError(f'Unsupported collider, cannot silently omit: {prim.GetPath()} {approximation}')
        vertices = np.asarray(UsdGeom.Mesh(prim).GetPointsAttr().Get(), float) * scale
        vertices, faces = convex_surface(apply(inverse(world(parent)) @ world(prim), vertices))
        colliders.append(dict(link=parent.GetName(), kind='arm' if parent.GetName() in arm_links else 'hand',
            path=str(prim.GetPath()), vertices=vertices.tolist(), faces=faces.tolist()))
    if filters:
        raise ValueError(f'Explicit pair filters require interpretation before proceeding: {filters}')
    # Verify extraction matches the previously validated FK link frames and hand hulls.
    base_inv = inverse(world(stage.GetPrimAtPath(config['base_path'])))
    zero = arm.link_transforms(np.zeros(6))
    zero.update(hand.link_transforms(np.zeros(6), zero[arm.wrist]))
    paths = {**arm.description['link_paths'], **hand.description['link_paths']}
    zero_error = max(float(np.max(np.abs(zero[name] - base_inv @ world(stage.GetPrimAtPath(path))))) for name, path in paths.items())
    assert zero_error < 2e-6, zero_error
    for item in colliders:
        if item['kind'] == 'hand':
            old = next(c for c in hand.colliders if c['link'] == item['link'])
            # Hull vertex ordering can change with the assembled world rotation.
            # Compare the actual point sets in both directions, not row indices.
            from scipy.spatial import cKDTree
            assert len(item['vertices']) == len(old['vertices'])
            assert cKDTree(item['vertices']).query(old['vertices'])[0].max() < 2e-7
            assert cKDTree(old['vertices']).query(item['vertices'])[0].max() < 2e-7
    return dict(colliders=colliders, excluded_joint_pairs=excluded, articulations=articulations,
        explicit_pair_filters=filters, zero_fk_matrix_error=zero_error,
        geometry='Exact hull of authored convexHull mesh points; not PhysX cooked-hull/contact equivalence',
        assembly_sha256=digest(ROOT/config['usd']),
        layers={layer.realPath: digest(layer.realPath) for layer in stage.GetUsedLayers() if layer.realPath})


class CollisionAudit:
    """FCL convex hulls, broad-phase AABBs, and only USD-authored joint exclusions."""
    def __init__(self, audit, arm, hand, workcell):
        import fcl
        self.fcl, self.arm, self.hand = fcl, arm, hand
        self.objects, self.names, self.kinds, self.links, self.locals = [], [], [], [], []
        self.centers, self.half = [], []
        for c in audit['colliders']:
            v, faces = np.asarray(c['vertices'], float), np.asarray(c['faces'], np.int32)
            polygons = np.c_[np.full(len(faces), 3), faces].ravel()
            shape = fcl.Convex(v, len(faces), polygons)
            self._add(shape, c['link'], c['kind'], c['link'], np.eye(4), v.min(0), v.max(0))
        self.robot_count = len(self.objects)
        for name, box in workcell.boxes().items():
            t = np.eye(4); t[:3, 3] = box['center']
            size = np.asarray(box['size'])
            self._add(fcl.Box(*size), name, 'environment', None, t, -size/2, size/2)
        geometry = json.loads((ROOT/'assets/models/can_mesh.json').read_text())
        for i, c in enumerate(geometry['collision_shapes']):
            assert c['type'] == 'cylinder'
            extent = np.array([c['radius'], c['radius'], c['height']/2])
            self._add(fcl.Cylinder(c['radius'], c['height']), f'can_{i}', 'can', None,
                      np.asarray(c['transform']), -extent, extent)
        self.centers, self.half = np.asarray(self.centers), np.asarray(self.half)
        excluded = {tuple(x['links']) for x in audit['excluded_joint_pairs']}
        self.pairs = {g: [] for g in GROUPS}
        for i in range(self.robot_count):
            for j in range(i+1, len(self.objects)):
                a, b = self.kinds[i], self.kinds[j]
                # The straight adapter and flange can have multiple shapes on
                # the same rigid body; internal shape overlap is not self contact.
                if j < self.robot_count and self.links[i] == self.links[j]:
                    continue
                if j < self.robot_count and tuple(sorted([self.links[i], self.links[j]])) in excluded:
                    continue
                if a == b:
                    group = a+'_self'
                elif b == 'environment':
                    # Robot root intentionally touches its own mounting pedestal.
                    if self.links[i] == arm.root and self.names[j] == 'Pedestal':
                        continue
                    group = 'environment'
                elif b == 'can':
                    group = a+'_can'
                else:
                    group = 'hand_arm'
                self.pairs[group].append((i, j))
        self.pairs = {g: np.asarray(p, dtype=int).reshape(-1, 2) for g, p in self.pairs.items()}
        self.request = fcl.CollisionRequest(num_max_contacts=32, enable_contact=True)
        self.world_from_base = workcell.world_from_base

    def _add(self, shape, name, kind, link, local, lower, upper):
        self.objects.append(self.fcl.CollisionObject(shape))
        self.names.append(name); self.kinds.append(kind); self.links.append(link); self.locals.append(local)
        self.centers.append((lower+upper)/2); self.half.append((upper-lower)/2)

    def state(self, q_arm, q_hand, can_world, groups=GROUPS):
        links = self.arm.link_transforms(q_arm)
        links.update(self.hand.link_transforms(q_hand, links[self.arm.wrist]))
        matrices = np.stack([self.world_from_base @ links[link] if link else
                            can_world @ local if kind == 'can' else local
                            for link, kind, local in zip(self.links, self.kinds, self.locals)])
        centers = np.einsum('nij,nj->ni', matrices[:, :3, :3], self.centers) + matrices[:, :3, 3]
        half = np.einsum('nij,nj->ni', np.abs(matrices[:, :3, :3]), self.half)
        lower, upper = centers-half, centers+half
        updated, found = set(), {}
        for group in groups:
            pairs = self.pairs[group]
            possible = np.all(lower[pairs[:, 0]] <= upper[pairs[:, 1]], axis=1) & np.all(lower[pairs[:, 1]] <= upper[pairs[:, 0]], axis=1)
            for i, j in pairs[possible]:
                for k in (i, j):
                    if k not in updated:
                        t = matrices[k]
                        self.objects[k].setTransform(self.fcl.Transform(t[:3, :3], t[:3, 3]))
                        updated.add(k)
                result = self.fcl.CollisionResult()
                if self.fcl.collide(self.objects[i], self.objects[j], self.request, result):
                    depth = max((float(c.penetration_depth) for c in result.contacts), default=0.)
                    # Separate positive penetration from tangent support/mount contact.
                    if depth > 1e-6:
                        found[group] = dict(pair=[self.names[i], self.names[j]], penetration_m=depth)
                        break
        return found


STATE = {}


def initialize(output, config_path=None, speed=1.0):
    config = json.loads(Path(config_path or ROOT/'config/tasks/can_pick/ik_demo2.json').read_text())
    arm, hand = ArmModel.load(ROOT/config['arm_model']), HandModel.load(ROOT/config['hand_model'])
    cell = Workcell.load(ROOT/config['workcell'])
    with np.load(ROOT/config['input'], allow_pickle=False) as d:
        source = {key: d[key].copy() for key in d.files}
    if not np.isfinite(speed) or speed <= 0:
        raise ValueError('Audit speed must be positive and finite')
    # Audit-only retiming: preserve every source pose, saved input and app config.
    source['timestamps_s'] = source['timestamps_s'][0] + (source['timestamps_s']-source['timestamps_s'][0])/speed
    source = interpolate_ik_source(source, len(source['timestamps_s']), config['trajectory_substeps'])
    order = [list(source['active_joint_names']).index(n) for n in hand.active_names]
    source['active_q_rad'] = source['active_q_rad'][:, order]
    alignment = cell.resolve_alignment(json.loads((ROOT/config['alignment']).read_text()))
    audit = json.loads((Path(output)/'collision_model.json').read_text())
    STATE.update(config=config, arm=arm, hand=hand, cell=cell, source=source,
        solver=ArmIK(arm, IKOptions(**config['solver'])), output=Path(output),
        world_from_source=np.asarray(alignment['world_from_source']),
        collision=CollisionAudit(audit, arm, hand, cell))


def run_point(task):
    ix, iy, x, y = task
    st = time.perf_counter()
    s = STATE; arm, hand, source, solver = (s[k] for k in ('arm', 'hand', 'source', 'solver'))
    times = source['timestamps_s']; n = len(times)
    world = s['world_from_source'].copy()
    initial_can = world @ source['object_transform'][0]
    world[:2, 3] += [x-initial_can[0, 3], y-initial_can[1, 3]]
    targets = inverse(s['cell'].world_from_base) @ world @ source['wrist_transform']
    cans = world @ source['object_transform']
    q = np.full((n, 6), np.nan); pos = np.full(n, np.nan); ori = pos.copy(); sigma = pos.copy(); condition = pos.copy()
    tested = np.zeros(n, bool); ok = tested.copy(); transition = tested.copy(); margins = pos.copy()
    transition_sigma = pos.copy(); transition_condition = pos.copy()
    row = dict(ix=ix, iy=iy, x_m=x, y_m=y, ik_success=False, collisions={}, first_failure=None)
    table = s['cell'].description['table']; lower = np.asarray(table['center_xy'])-np.asarray(table['size_xy'])/2
    upper = np.asarray(table['center_xy'])+np.asarray(table['size_xy'])/2
    # The actual bottom flange radius is 38 mm; derive footprint from authored cylinders.
    geom = json.loads((ROOT/'assets/models/can_mesh.json').read_text())
    footprint_low, footprint_high = [], []
    for c in geom['collision_shapes']:
        t = cans[0] @ np.asarray(c['transform']); axis = t[:3, 2]
        extent = c['height']/2*np.abs(axis) + c['radius']*np.sqrt(np.maximum(0, 1-axis**2))
        footprint_low.append(t[:2, 3]-extent[:2]); footprint_high.append(t[:2, 3]+extent[:2])
    row['initial_can_supported'] = bool(np.all(np.min(footprint_low, axis=0) >= lower-1e-8) and np.all(np.max(footprint_high, axis=0) <= upper+1e-8))
    for i, target in enumerate(targets):
        result = solver.solve(target, s['config']['seed_q_rad'] if i == 0 else q[i-1],
                              previous=None if i == 0 else q[i-1], dt=None if i == 0 else times[i]-times[i-1])
        tested[i] = True; q[i] = result.q; pos[i] = result.position_error_m; ori[i] = result.orientation_error_rad
        sigma[i] = result.sigma_min; condition[i] = result.condition; margins[i] = result.joint_limit_distance_rad
        transition[i] = result.success
        transition_sigma[i] = result.sigma_min; transition_condition[i] = result.condition
        if result.success and i:
            t = solver.transition(q[i-1], q[i]); transition[i] = t['valid']
            transition_sigma[i] = t['sigma_min']; transition_condition[i] = t['condition_max']
            if not t['valid']: result.success=False; result.reason+=';singular_transition'
        if not source['valid'][i] or (i and not source['transition_valid'][i]):
            result.success=False; result.reason+=';invalid_source_reference'
        if i and np.any(np.abs(source['active_q_rad'][i]-source['active_q_rad'][i-1])/(times[i]-times[i-1]) > hand.velocity+1e-6):
            result.success=False; result.reason+=';finger_velocity_limit'
        ok[i] = result.success
        if not result.success:
            row['first_failure'] = dict(sample=i, source_frame_id=int(source['frame_ids'][i]),
                source_interval=source['source_interval_frame_ids'][i].tolist(), reason=result.reason,
                position_error_m=result.position_error_m, orientation_error_rad=result.orientation_error_rad)
            break  # One failed required frame is enough to reject this complete trajectory.
    row['ik_success'] = bool(ok.all() and transition.all())
    row['tested_samples'] = int(tested.sum())
    row['near_singular_samples'] = np.flatnonzero((sigma < solver.options.near_sigma_min) | (condition > solver.options.near_condition)).tolist()
    row['near_limit_samples'] = np.flatnonzero(margins < solver.options.limit_warning_rad).tolist()
    row['near_singular_transition_samples'] = np.flatnonzero(tested & ((transition_sigma < solver.options.near_sigma_min) | (transition_condition > solver.options.near_condition))).tolist()
    row['min_tested_sigma'] = float(np.nanmin(sigma))
    row['min_transition_sigma'] = float(np.nanmin(transition_sigma))
    row['max_transition_condition'] = float(np.nanmax(transition_condition))
    if row['ik_success']:
        assert np.max(np.abs(np.diff(q, axis=0))) <= solver.options.max_joint_step_rad+1e-9
        assert np.all(np.abs(np.diff(q, axis=0))/np.diff(times)[:, None] <= arm.velocity+1e-9)
        row['max_joint_step_deg'] = float(np.rad2deg(np.max(np.abs(np.diff(q, axis=0)))))
        row['max_joint_speed_rad_s'] = float(np.max(np.abs(np.diff(q, axis=0))/np.diff(times)[:,None]))
        row['max_position_error_m'] = float(pos.max()); row['max_orientation_error_deg'] = float(np.rad2deg(ori.max()))
        row['min_sigma'] = float(sigma.min())
        # Same piecewise-linear joint path consumed by JointReference, with object SLERP.
        rotations = Slerp(times, Rotation.from_matrix(cans[:, :3, :3]))
        subdivisions = solver.options.transition_samples
        collision_states = []
        for i in range(n):
            alphas = [0.] if i == n-1 else np.arange(subdivisions)/subdivisions
            for alpha in alphas:
                j = min(i+1, n-1); now = (1-alpha)*times[i]+alpha*times[j]
                can = np.eye(4); can[:3, :3] = rotations(now).as_matrix(); can[:3, 3] = (1-alpha)*cans[i, :3, 3]+alpha*cans[j, :3, 3]
                active_groups = [g for g in GROUPS if g not in row['collisions']]
                if active_groups:
                    found = s['collision'].state((1-alpha)*q[i]+alpha*q[j],
                        (1-alpha)*source['active_q_rad'][i]+alpha*source['active_q_rad'][j], can, active_groups)
                    for group, detail in found.items():
                        row['collisions'][group] = dict(**detail, timestamp_s=float(now), ik_interval=i, alpha=float(alpha))
                collision_states.append(now)
        row['collision_samples'] = len(collision_states)
        row['collision_free'] = not row['collisions']
    else:
        row['collision_free'] = None; row['collision_samples'] = 0
    row['elapsed_s'] = time.perf_counter()-st
    name = f'{ix:02}_{iy:02}'
    np.savez_compressed(s['output']/'points'/f'{name}.npz', timestamps_s=times, frame_ids=source['frame_ids'],
        q_arm=q, q_finger=source['active_q_rad'], tested=tested, success=ok, transition_valid=transition,
        wrist_target_base=targets, object_transform_world=cans, position_error_m=pos, orientation_error_rad=ori,
        sigma_min=sigma, condition=condition, transition_sigma_min=transition_sigma,
        transition_condition_max=transition_condition, joint_limit_distance_rad=margins, world_from_source=world)
    (s['output']/'points'/f'{name}.json').write_text(json.dumps(row, indent=2)+'\n')
    return row


def plot(output, rows, metadata):
    import matplotlib
    matplotlib.use('Agg')
    import matplotlib.pyplot as plt
    from matplotlib import font_manager
    from matplotlib.lines import Line2D
    from matplotlib.patches import Rectangle
    font = '/usr/share/fonts/opentype/noto/NotoSansCJK-Regular.ttc'
    if Path(font).exists():
        font_manager.fontManager.addfont(font)
        plt.rcParams['font.family'] = font_manager.FontProperties(fname=font).get_name()
    plt.rcParams['axes.unicode_minus'] = False
    fig, axes = plt.subplots(1, 2, figsize=(14, 11.5), sharey=True)
    colors = dict(pass_='#1c956d', fail='#d6dbe0', hand_arm='#dc3545', self='#9b59b6', environment='#ed9a27', can='#287dc0')
    for ax in axes:
        ax.set_aspect('equal'); ax.add_patch(Rectangle((25, -80), 80, 160, fill=False, lw=1.8, ec='#253747'))
        ax.add_patch(Rectangle((-25, -25), 50, 50, fc='#ecf0f3', ec='#748698', lw=1.2))
        ax.plot(0, 0, 'o', color='#253747', ms=8); ax.text(0, -9, 'RB3\n베이스', ha='center', va='top', fontsize=10)
        ax.annotate('', xy=(20, 0), xytext=(3, 0), arrowprops=dict(arrowstyle='->', color='#253747'))
        ax.set_xlim(-29, 109); ax.set_ylim(-86, 86); ax.set_xticks(np.arange(-20, 101, 20)); ax.set_yticks(np.arange(-80, 81, 20))
        ax.set_xlabel('로봇 전방 X (cm)', fontsize=11); ax.grid(alpha=.12)
    axes[0].set_ylabel('책상 가로 Y (cm)', fontsize=11)
    for r in rows:
        x, y = r['x_m']*100, r['y_m']*100
        axes[0].scatter(x, y, s=29, marker='s', color=colors['pass_' if r['ik_success'] else 'fail'], edgecolors='none')
        collision = r['collisions']
        category = 'fail' if not r['ik_success'] else 'hand_arm' if 'hand_arm' in collision else 'self' if ('arm_self' in collision or 'hand_self' in collision) else 'environment' if 'environment' in collision else 'can' if ('hand_can' in collision or 'arm_can' in collision) else 'pass_'
        axes[1].scatter(x, y, s=29, marker='s', color=colors[category], edgecolors='none')
        if not r['initial_can_supported']:
            for ax in axes: ax.scatter(x, y, s=18, marker='x', color='#5d6670', linewidths=.75)
    for ax in axes:
        ax.scatter(30, 0, marker='*', s=165, facecolors='none', edgecolors='#162638', linewidths=1.5, zorder=8)
    ik = sum(r['ik_success'] for r in rows)
    usable = sum(r['ik_success'] and r['collision_free'] and r['initial_can_supported'] for r in rows)
    axes[0].set_title(f'① 전체 궤적 IK 통과: {ik} / {len(rows)} 위치', fontsize=14, pad=16)
    axes[1].set_title(f'② 충돌·캔 지지까지 통과: {usable} 위치', fontsize=14, pad=16)
    def marker(c, label): return Line2D([], [], color=c, marker='s', linestyle='', markersize=9, label=label)
    axes[0].legend(handles=[marker(colors['pass_'], '53개 IK + 전이 제약 통과'), marker(colors['fail'], '현재 solver에서 전체 궤적 실패'),
        Line2D([], [], color='#5d6670', marker='x', linestyle='', label='초기 캔 밑면이 상판 경계 밖'),
        Line2D([], [], color='#162638', marker='*', markerfacecolor='none', markersize=12, linestyle='', label='현재 기본 위치 (30, 0) cm')],
        loc='upper left', bbox_to_anchor=(0, -.095), frameon=False, fontsize=10)
    axes[1].legend(handles=[marker(colors['pass_'], '검사한 충돌 형상 쌍 모두 통과'), marker(colors['hand_arm'], '손–팔 관통'),
        marker(colors['self'], '그 외 자기 관통 (팔–팔 / 손–손)'), marker(colors['environment'], '책상·받침대·바닥 관통'),
        marker(colors['can'], '캔 관통'), marker(colors['fail'], 'IK 실패 → 충돌 판정 보류')],
        loc='upper left', bbox_to_anchor=(0, -.095), frameon=False, fontsize=10, ncol=2)
    fig.suptitle('리타게팅 궤적 기반 · 책상 위 캔 위치별 RB3 IK / 충돌 지도', fontsize=19, fontweight='bold', y=.98)
    fig.text(.5, .945, '5 cm 격자 · 초기 캔 중심 XY · 기존 −90° 방향 유지 · 손–캔 상대 동작 고정 · RL 미사용', ha='center', fontsize=11, color='#485867')
    fig.text(.5, .025, '27개 원본 자세 → 53개 IK (5.2 s) · 위치 0.01 mm / 회전 0.00573° 허용오차\n'
             '통과 궤적당 충돌 1,041개 시각 표본 · USD convex hull 24개 · 관절 연결부 충돌 제외\n'
             '회색은 제한된 multi-start 탐색 실패이며 전역 불가능 증명이 아님 · 동역학/물리 파지 성공 검증 아님',
             ha='center', va='bottom', fontsize=10, color='#485867')
    fig.subplots_adjust(top=.90, bottom=.23, wspace=.12, left=.08, right=.97)
    fig.savefig(output/'table_ik_collision_map.png', dpi=190, facecolor='white')
    fig.savefig(output/'table_ik_collision_map.svg', facecolor='white')
    plt.close(fig)


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--output', type=Path, default=ROOT/'local/reports/table_ik_scan')
    p.add_argument('--config', type=Path, default=ROOT/'config/tasks/can_pick/ik_demo2.json')
    p.add_argument('--no-plot', action='store_true', help='Use a separate comparison plot instead of the historical layout')
    p.add_argument('--workers', type=int, default=6)
    p.add_argument('--speed', type=float, default=1.0, help='Audit-only trajectory speed multiplier')
    p.add_argument('--current-only', action='store_true')
    p.add_argument('--plot-only', action='store_true')
    args = p.parse_args(); output = args.output.resolve(); (output/'points').mkdir(parents=True, exist_ok=True)
    config = json.loads(args.config.read_text())
    if not args.plot_only:
        audit = extract_collision_audit(config)
        (output/'collision_model.json').write_text(json.dumps(audit)+'\n')
    initialize(output, args.config, args.speed)
    table = STATE['cell'].description['table']; step=.05
    low=np.asarray(table['center_xy'])-np.asarray(table['size_xy'])/2
    high=np.asarray(table['center_xy'])+np.asarray(table['size_xy'])/2
    xs, ys = [np.round(np.arange(a, b+step/2, step), 10) for a,b in zip(low, high)]
    tasks = [(ix, iy, float(x), float(y)) for ix,x in enumerate(xs) for iy,y in enumerate(ys)]
    current_xy = (STATE['world_from_source'] @ STATE['source']['object_transform'][0])[:2,3]
    if args.current_only: tasks=[t for t in tasks if np.allclose(t[2:], current_xy)]
    config_paths = [ROOT/config[k] for k in ('input','usd','arm_model','hand_model','alignment','workcell')]
    config_paths += [args.config.resolve(), ROOT/'assets/models/can_mesh.json', Path(__file__)]
    config_paths += [ROOT/'src/dex_manipulation'/name for name in ('fk.py','ik.py','scene.py','transforms.py','usd.py')]
    metadata = dict(input_hashes={str(p.relative_to(ROOT)): digest(p) for p in config_paths}, grid_step_m=step,
        grid_shape=[len(xs),len(ys)], solver=asdict(STATE['solver'].options), playback_speed=args.speed,
        source_frames=STATE['source']['frame_ids'][STATE['source']['source_frame_mask']].tolist(),
        reference_duration_s=float(np.ptp(STATE['source']['timestamps_s'])),
        pair_counts={g:len(p) for g,p in STATE['collision'].pairs.items()},
        exclusions='Only direct disabled-collision USD joint pairs and root/pedestal support; no generic link-name exclusions',
        collision_threshold_m=1e-6,
        collision_samples_per_complete_trajectory=(len(STATE['source']['timestamps_s'])-1)*STATE['solver'].options.transition_samples+1,
        current_xy_m=current_xy.tolist(), config_path=str(args.config.resolve().relative_to(ROOT)),
        model_fingerprint=model_fingerprint(STATE['arm']),
        method='Existing ArmIK, closest initial branch, fixed seed per placement; stop at first IK failure; post-check collisions on all successful paths',
        not_proven=['global IK infeasibility', 'collision-free alternative IK branches', 'continuous-time collision freedom',
                    'PhysX cooked-hull equivalence', 'physical grasp', 'measured hardware calibration'])
    manifest=output/'manifest.json'
    if manifest.exists():
        old=json.loads(manifest.read_text())
        if old['input_hashes']!=metadata['input_hashes'] or old.get('playback_speed',1.0)!=args.speed:
            raise ValueError('Inputs/tool/speed changed; use a new output directory.')
    else: manifest.write_text(json.dumps(metadata,indent=2)+'\n')
    rows=[]; pending=[]
    for task in tasks:
        path=output/'points'/f'{task[0]:02}_{task[1]:02}.json'
        if path.exists(): rows.append(json.loads(path.read_text()))
        else: pending.append(task)
    start=time.perf_counter()
    if args.plot_only and pending: raise ValueError('Cannot plot incomplete grid')
    if pending:
        with ProcessPoolExecutor(max_workers=args.workers, mp_context=mp.get_context('spawn'), initializer=initialize, initargs=(str(output),str(args.config.resolve()),args.speed)) as pool:
            futures=[pool.submit(run_point, task) for task in pending]
            for future in as_completed(futures):
                row=future.result(); rows.append(row)
                if len(rows)%10==0 or len(rows)==len(tasks) or args.current_only:
                    print(f'[scan] {len(rows)}/{len(tasks)} IK={sum(r["ik_success"] for r in rows)} '
                          f'clear={sum(bool(r["collision_free"]) for r in rows)} elapsed={time.perf_counter()-start:.1f}s', flush=True)
    rows.sort(key=lambda r:(r['ix'],r['iy']))
    summary=dict(total=len(rows),initial_can_supported=sum(r['initial_can_supported'] for r in rows),
        ik_pass=sum(r['ik_success'] for r in rows),
        collision_free=sum(bool(r['collision_free']) for r in rows),
        supported_collision_free=sum(r['ik_success'] and r['collision_free'] and r['initial_can_supported'] for r in rows),
        collision_counts={g:sum(g in r['collisions'] for r in rows) for g in GROUPS},
        current=next((r for r in rows if np.allclose([r['x_m'],r['y_m']],current_xy)),None))
    (output/'summary.json').write_text(json.dumps(summary,indent=2)+'\n')
    (output/'grid.json').write_text(json.dumps(rows,indent=2)+'\n')
    if not args.current_only and not args.no_plot: plot(output,rows,metadata)
    print(json.dumps(summary,indent=2),flush=True)


if __name__ == '__main__':
    main()
